
This project consists of 2 part: raw and analysis (since the data is already clean, build folder is no needed)

- raw: raw datasets 
- analysis: consist of codes for each exercise and their outputs
